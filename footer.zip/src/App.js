import "./App.css";

function App() {
  return (
    <div>
      <footer>
        <div className="footerall">
          <div className="footerLogoContent">
            <div className="footerLogo">
              <i class="fa-solid fa-shop"></i>
              <h2>LiveShop</h2>
            </div>
            <div className="textLogo">
              <p>
                Lorem ipsum dolor sit amet sdjfh dsfg res gr edgdfd nice to meet
                you too so good i like this ok bruh are you kidding me hey you
                men
              </p>
            </div>
          </div>
          <div className="footerUlAll">
            <div className="ulContent">
              <p>Lorem</p>
              <div className="ulPaddingfooter">
                <ul>
                  <li>Lorem.</li>
                  <li>Nisi.</li>
                  <li>Dolore!</li>
                  <li>Consequuntur!</li>
                </ul>
              </div>
            </div>
            <div className="ulContent">
              <p>Lorem</p>
              <div className="ulPaddingfooter">
                <ul>
                  <li>Lorem.</li>
                  <li>Nisi.</li>
                  <li>Dolore!</li>
                  <li>Consequuntur!</li>
                </ul>
              </div>
            </div>
            <div className="ulContent">
              <p>Lorem</p>
              <div className="ulPaddingfooter">
                <ul>
                  <li>Lorem.</li>
                  <li>Nisi.</li>
                  <li>Dolore!</li>
                  <li>Consequuntur!</li>
                </ul>
              </div>
            </div>
          </div>
        <div className="footerContact">
          <div className="footerContacth3">
            <h3>Conatact</h3>
          </div>
          <div className="footerContacta">
            <a href="tel:+998 00 000 00 00">+998 00 000 00 00</a>
          </div>
          <div className="footerContactp">
            <p>Uzbekistan, Tashkent Olmazor, Farobiy st.</p>
          </div>
          <div className="footerIcondf">
            <a href="#" className="btn_footer"><i className="fa-brands fa-instagram"></i></a>
            <a href="#" className="btn_footer"><i className="fa-brands fa-instagram"></i></a>
            <a href="#" className="btn_footer"><i className="fa-brands fa-instagram"></i></a>
          </div>
        </div>
        </div>



        <div className="footerEndText">
          <h3>@LiveShop. © 2023. All Rights Reserved. Designed by Item</h3>
        </div>
      </footer>
    </div>
  );
}

export default App;




            
          //   <h3>Conatact</h3>
          //   
          //   
          //   <div className="footerIconsdf">
          //     <div>
          //     
          //     </div>
          //     <div>
          //     <a href="#"><i class="fa-brands fa-instagram"></i></a>
          //     </div>
          //     <div>
          //     <a href="#"><i class="fa-brands fa-square-instagram"></i></a>
          //     </div>
          //   </div>
          // </div>
          // </div>